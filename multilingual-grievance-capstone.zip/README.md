# Multilingual Citizen-Grievance Triage with SLA Prediction and Human Escalation

A deployable capstone prototype for receiving citizen complaints, detecting language, suggesting categories, finding similar/duplicate cases, routing complaints, tracking SLA deadlines, and supporting human review and appeals.

## Stack
- **Frontend:** React + Vite
- **Backend:** Node.js + Express
- **Database:** PostgreSQL
- **Triage logic:** transparent, rule-based baseline (easy to replace with a trained NLP model)
- **Deployment:** Vercel (frontend) + Render (API) + Neon/Supabase PostgreSQL

> This is a working academic prototype. Automated language/category/duplicate suggestions are assistive only. A staff member must review decisions before consequential action. The sample rules are not a production-grade language model.

## Features
- Complaint submission with English, Hindi and Marathi examples
- Basic language detection and category suggestion
- Similarity-based duplicate candidate search
- Priority-based SLA deadline calculation
- Complaint queue with status, category, assigned department and SLA state
- Staff workflow: accept, resolve, escalate and route
- Citizen appeal submission
- Dashboard analytics and audit trail
- Seed/demo records when the database is empty
- Responsive interface and REST API

## Run locally

Requirements: Node.js 20+ and PostgreSQL 14+.

1. Create a PostgreSQL database, for example `grievance_capstone`.
2. Apply the schema:
   ```bash
   psql "$DATABASE_URL" -f server/schema.sql
   ```
3. Configure the API:
   ```bash
   cp server/.env.example server/.env
   ```
   Set `DATABASE_URL` and optionally `PORT`, `CLIENT_ORIGIN`.
4. Configure the frontend:
   ```bash
   cp client/.env.example client/.env
   ```
   Set `VITE_API_URL=http://localhost:5000/api`.
5. Install and run:
   ```bash
   npm install
   npm install --prefix server
   npm install --prefix client
   npm run dev
   ```
   Frontend: `http://localhost:5173` | API: `http://localhost:5000`

If you do not have PostgreSQL locally, create a free hosted database on Neon or Supabase and use its connection string.

## Deploy

### 1. Database
Create a PostgreSQL database on Neon or Supabase. Copy its connection string and run `server/schema.sql` against it using the provider's SQL editor or `psql`.

### 2. Backend on Render
- Push this folder to a GitHub repository.
- In Render, create **New → Web Service** and connect the repository.
- Root directory: `server`
- Build command: `npm install`
- Start command: `npm start`
- Add environment variables:
  - `DATABASE_URL` = your PostgreSQL connection string
  - `CLIENT_ORIGIN` = your Vercel frontend URL (after deploying frontend; temporarily use `*` only for testing)
  - `NODE_ENV` = `production`
- Deploy. Test `https://YOUR-API.onrender.com/api/health`.

### 3. Frontend on Vercel
- Import the same GitHub repository into Vercel.
- Framework preset: **Vite**
- Root directory: `client`
- Build command: `npm run build`
- Output directory: `dist`
- Add environment variable:
  - `VITE_API_URL` = `https://YOUR-API.onrender.com/api`
- Deploy, then set `CLIENT_ORIGIN` on Render to your exact Vercel domain and redeploy the API.

### 4. Verify
- Open the deployed frontend.
- Submit a sample complaint in English, Hindi or Marathi.
- Confirm it appears in the queue, inspect suggested category and similar cases, update its status, submit an appeal and review analytics.
- Keep secrets in hosting environment variables; never commit `.env` files or real citizen personal data.

## API
- `GET /api/health` — health check
- `GET /api/complaints` — complaint queue
- `POST /api/complaints` — submit and triage a complaint
- `PATCH /api/complaints/:id` — update status, category, department or priority
- `POST /api/complaints/:id/appeal` — submit an appeal
- `GET /api/analytics` — dashboard metrics
- `GET /api/audit` — recent audit events

## Suggested evaluation
Compare rule-based category suggestions with a manually labelled test set using precision, recall and F1. Measure duplicate candidate precision, routing accuracy, SLA compliance, response latency and usability. Include edge cases (empty/very short text, mixed-language text, repeated submissions, urgent safety-related complaints) and document the limitations of the baseline.
