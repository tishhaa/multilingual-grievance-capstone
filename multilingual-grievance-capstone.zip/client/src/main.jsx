import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import { Activity, AlertTriangle, ArrowUpRight, CheckCircle2, ChevronDown, Clock3, FileText, Filter, Globe2, LayoutDashboard, ListTodo, MessageSquareText, Plus, Search, ShieldCheck, Sparkles, Users, X } from "lucide-react";
import "./styles.css";

const API = (import.meta.env.VITE_API_URL || "http://localhost:5000/api").replace(/\/$/, "");
const departments = ["Water Department","Public Works","Sanitation Department","Electrical Department","Public Safety Cell","Drainage Department","Citizen Services","General Helpdesk"];
const categories = ["Water Supply","Roads & Potholes","Waste Management","Electricity & Streetlights","Public Safety","Drainage & Sewage","Certificates & Documents","Other"];
const statuses = ["Submitted","Under Review","In Progress","Resolved","Escalated","Rejected"];
const fmt = d => d ? new Date(d).toLocaleString("en-IN",{dateStyle:"medium",timeStyle:"short"}) : "—";
const initials = name => (name||"C").split(" ").map(x=>x[0]).join("").slice(0,2).toUpperCase();

function App(){
  const [page,setPage] = useState("overview");
  const [complaints,setComplaints] = useState([]);
  const [analytics,setAnalytics] = useState({total:0,resolved:0,overdue:0,duplicates:0,pending:0,byCategory:[],byStatus:[]});
  const [audit,setAudit] = useState([]);
  const [loading,setLoading] = useState(true);
  const [error,setError] = useState("");
  const [search,setSearch] = useState("");
  const [filter,setFilter] = useState("All");
  const [selected,setSelected] = useState(null);
  const [showForm,setShowForm] = useState(false);
  const [toast,setToast] = useState("");
  const [form,setForm] = useState({citizenName:"",contact:"",title:"",description:""});
  const [appeal,setAppeal] = useState("");
  const [submitting,setSubmitting] = useState(false);

  async function load(){
    try{
      setError("");
      const [c,a,ev] = await Promise.all([fetch(`${API}/complaints`),fetch(`${API}/analytics`),fetch(`${API}/audit`)]);
      if(!c.ok||!a.ok||!ev.ok) throw new Error("API could not load data. Check that the backend and database are running.");
      setComplaints(await c.json()); setAnalytics(await a.json()); setAudit(await ev.json());
    }catch(e){setError(e.message||"Unable to connect to API.");}
    finally{setLoading(false);}
  }
  useEffect(()=>{load();},[]);
  const filtered = useMemo(()=>complaints.filter(c=>{
    const q=search.toLowerCase();
    const match=[c.title,c.description,c.citizen_name,c.id,c.category,c.department].some(v=>String(v||"").toLowerCase().includes(q));
    return match&&(filter==="All"||c.status===filter);
  }),[complaints,search,filter]);
  const notify = msg=>{setToast(msg);setTimeout(()=>setToast(""),3500);};
  async function submitComplaint(e){
    e.preventDefault(); setSubmitting(true);
    try{
      const r=await fetch(`${API}/complaints`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(form)});
      const data=await r.json(); if(!r.ok) throw new Error(data.error||"Submission failed");
      setForm({citizenName:"",contact:"",title:"",description:""});setShowForm(false);setSelected(data);await load();
      notify(data.duplicateCandidate?"Complaint received — a similar case was flagged for review.":"Complaint submitted successfully.");
    }catch(e){notify(e.message);}finally{setSubmitting(false);}
  }
  async function updateComplaint(id,changes){
    try{const r=await fetch(`${API}/complaints/${id}`,{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify(changes)});const data=await r.json();if(!r.ok)throw new Error(data.error);await load();setSelected(data);notify("Complaint record updated.");}
    catch(e){notify(e.message||"Update failed.");}
  }
  async function submitAppeal(){
    if(!appeal.trim())return;
    try{const r=await fetch(`${API}/complaints/${selected.id}/appeal`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({appeal})});const data=await r.json();if(!r.ok)throw new Error(data.error);setSelected(data);setAppeal("");await load();notify("Appeal submitted for human review.");}
    catch(e){notify(e.message||"Appeal failed.");}
  }
  const nav=[{id:"overview",label:"Overview",icon:LayoutDashboard},{id:"complaints",label:"Complaints",icon:ListTodo},{id:"analytics",label:"Analytics",icon:Activity},{id:"audit",label:"Audit trail",icon:ShieldCheck}];
  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-mark"><Globe2 size={22}/></div><div><b>JanSetu</b><small>Citizen Services</small></div></div>
      <div className="workspace"><span className="workspace-dot"></span><span>Municipal helpdesk</span><ChevronDown size={14}/></div>
      <p className="nav-caption">WORKSPACE</p>
      <nav>{nav.map(n=><button key={n.id} className={`nav-link ${page===n.id?"active":""}`} onClick={()=>{setPage(n.id);setSelected(null)}}><n.icon size={18}/><span>{n.label}</span>{n.id==="complaints"&&<em>{complaints.length}</em>}</button>)}</nav>
      <div className="sidebar-bottom"><div className="help-card"><div className="help-icon"><Sparkles size={17}/></div><b>Human-first triage</b><p>AI suggestions support staff. Final decisions stay with people.</p></div><div className="profile"><div className="avatar">AD</div><div className="profile-text"><b>Admin desk</b><small>Staff workspace</small></div><button className="icon-button" title="Profile"><ChevronDown size={15}/></button></div></div>
    </aside>
    <main className="main">
      <header className="topbar"><div className="crumb"><span>Workspace</span><span className="slash">/</span><b>{nav.find(n=>n.id===page)?.label}</b></div><div className="top-actions"><span className="live"><i></i> System operational</span><button className="icon-button" title="Refresh" onClick={load}><Activity size={17}/></button><div className="avatar small">AD</div></div></header>
      {error&&<div className="error-banner"><AlertTriangle size={17}/><span>{error} Set up the API using the README deployment instructions.</span><button onClick={load}>Retry</button></div>}
      {page==="overview"&&<Overview analytics={analytics} complaints={complaints} onNew={()=>setShowForm(true)} onView={c=>setSelected(c)} onAll={()=>setPage("complaints")}/>}
      {page==="complaints"&&<section className="page-content"><div className="page-heading"><div><p className="eyebrow">CASE MANAGEMENT</p><h1>Complaint queue</h1><p className="subheading">Review, route and track citizen requests in one place.</p></div><button className="primary" onClick={()=>setShowForm(true)}><Plus size={17}/> New complaint</button></div><div className="toolbar"><div className="searchbox"><Search size={17}/><input placeholder="Search complaints, citizens, IDs..." value={search} onChange={e=>setSearch(e.target.value)}/></div><div className="filterbox"><Filter size={16}/><select value={filter} onChange={e=>setFilter(e.target.value)}><option>All</option>{statuses.map(s=><option key={s}>{s}</option>)}</select></div><span className="result-count">{filtered.length} records</span></div><ComplaintTable rows={filtered} onView={setSelected}/></section>}
      {page==="analytics"&&<Analytics analytics={analytics} complaints={complaints}/>}
      {page==="audit"&&<Audit audit={audit}/>}
      <footer><span>JanSetu · Capstone prototype</span><span>Multilingual grievance triage <b>•</b> Human review enabled</span></footer>
    </main>
    {showForm&&<div className="overlay" onMouseDown={e=>e.target===e.currentTarget&&setShowForm(false)}><div className="modal"><div className="modal-head"><div><p className="eyebrow">CITIZEN INTAKE</p><h2>Submit a complaint</h2><p className="subheading">Share the issue in English, Hindi or Marathi.</p></div><button className="icon-button" onClick={()=>setShowForm(false)}><X/></button></div><form onSubmit={submitComplaint} className="complaint-form"><label>Citizen name <span>*</span><input required value={form.citizenName} onChange={e=>setForm({...form,citizenName:e.target.value})} placeholder="e.g. Aditi Sharma"/></label><label>Contact (optional)<input value={form.contact} onChange={e=>setForm({...form,contact:e.target.value})} placeholder="Phone or email"/></label><label>Complaint title <span>*</span><input required value={form.title} onChange={e=>setForm({...form,title:e.target.value})} placeholder="Briefly describe the issue"/></label><label>Description <span>*</span><textarea required minLength={8} rows="5" value={form.description} onChange={e=>setForm({...form,description:e.target.value})} placeholder="Where is the issue and what happened? You may write in English, हिन्दी or मराठी."/></label><div className="privacy-note"><ShieldCheck size={16}/> Triage produces suggestions only. Staff review routing and priority.</div><div className="modal-actions"><button type="button" className="secondary" onClick={()=>setShowForm(false)}>Cancel</button><button className="primary" disabled={submitting}>{submitting?"Submitting…":"Submit complaint"} <ArrowUpRight size={16}/></button></div></form></div></div>}
    {selected&&<Detail complaint={selected} onClose={()=>setSelected(null)} onUpdate={updateComplaint} appeal={appeal} setAppeal={setAppeal} onAppeal={submitAppeal}/>}
    {toast&&<div className="toast"><CheckCircle2 size={17}/>{toast}</div>}
  </div>
}

function Overview({analytics:a,complaints,onNew,onView,onAll}){
 const recent=complaints.slice(0,5);
 return <section className="page-content"><div className="welcome-row"><div><p className="eyebrow">CITIZEN SERVICE OPERATIONS</p><h1>Good day, Admin <span>✦</span></h1><p className="subheading">Here’s what’s happening across your grievance desk.</p></div><button className="primary" onClick={onNew}><Plus size={17}/> New complaint</button></div>
 <div className="hero-banner"><div className="hero-copy"><span className="hero-tag"><Sparkles size={13}/> SMART GRIEVANCE WORKFLOW</span><h2>Every voice deserves<br/>a clear path to resolution.</h2><p>One workspace to understand, route and resolve citizen concerns — across languages.</p><button className="hero-button" onClick={onNew}>Register a complaint <ArrowUpRight size={15}/></button></div><div className="hero-art"><div className="orbit orbit-one"></div><div className="orbit orbit-two"></div><div className="art-card"><div className="art-icon"><MessageSquareText size={22}/></div><div className="art-lines"><i></i><i></i><i></i></div><div className="art-check"><CheckCircle2 size={20}/></div></div><div className="art-chip chip-top"><Globe2 size={15}/> 3 languages</div><div className="art-chip chip-bottom"><Clock3 size={15}/> SLA tracking</div></div></div>
 <div className="stats-grid"><Stat label="Total complaints" value={a.total||0} icon={FileText} tone="blue" note="All submissions"/><Stat label="Awaiting action" value={a.pending||0} icon={Clock3} tone="amber" note="Submitted or under review"/><Stat label="Resolved cases" value={a.resolved||0} icon={CheckCircle2} tone="green" note="Marked as resolved"/><Stat label="SLA overdue" value={a.overdue||0} icon={AlertTriangle} tone="red" note="Requires attention"/></div>
 <div className="section-row"><div><h2>Recent complaints</h2><p className="subheading">Latest cases submitted to the helpdesk.</p></div><button className="text-button" onClick={onAll}>View all <ArrowUpRight size={15}/></button></div>
 {recent.length?<ComplaintTable rows={recent} onView={onView} compact/>:<div className="empty-state"><div className="empty-icon"><MessageSquareText/></div><b>No complaints yet</b><p>New citizen submissions will appear here.</p><button className="secondary" onClick={onNew}>Create first complaint</button></div>}
 <div className="bottom-grid"><div className="panel"><div className="panel-title"><div><h3>Cases by category</h3><p>Distribution of incoming concerns</p></div><span className="panel-symbol"><Activity size={17}/></span></div>{a.byCategory?.length?a.byCategory.slice(0,5).map((c,i)=><div className="bar-row" key={c.name}><div className="bar-label"><span>{c.name}</span><b>{c.value}</b></div><div className="bar-track"><i style={{width:`${Math.max(5,c.value/Math.max(...a.byCategory.map(x=>x.value))*100)}%`}}/></div></div>):<p className="muted">Category insights appear after submissions.</p>}</div><div className="panel workflow-panel"><div className="panel-title"><div><h3>Workflow snapshot</h3><p>From intake to resolution</p></div><span className="panel-symbol"><Activity size={17}/></span></div><div className="workflow-step"><span className="step-icon blue-bg"><MessageSquareText size={16}/></span><div><b>Complaint intake</b><small>Multilingual submission</small></div><span className="step-count">{a.total||0}</span></div><div className="workflow-step"><span className="step-icon amber-bg"><Users size={16}/></span><div><b>Human review</b><small>Validation and routing</small></div><span className="step-count">{a.pending||0}</span></div><div className="workflow-step"><span className="step-icon green-bg"><CheckCircle2 size={16}/></span><div><b>Resolved</b><small>Completed cases</small></div><span className="step-count">{a.resolved||0}</span></div></div></div>
 </section>
}
function Stat({label,value,icon:Icon,tone,note}){return <div className="stat-card"><div className={`stat-icon ${tone}`}><Icon size={19}/></div><span className="stat-label">{label}</span><strong>{value}</strong><small>{note}</small></div>}
function ComplaintTable({rows,onView,compact=false}){
 return <div className="table-wrap"><table><thead><tr><th>COMPLAINT</th><th>CATEGORY</th><th>PRIORITY</th><th>STATUS</th><th>SLA DUE</th><th></th></tr></thead><tbody>{rows.map(c=><tr key={c.id} onClick={()=>onView(c)} className="click-row"><td><div className="case-cell"><div className="case-icon"><FileText size={16}/></div><div><b>{c.title}</b><small>{c.citizen_name} · #{String(c.id).slice(0,8).toUpperCase()}</small></div></div></td><td><span className="category-text">{c.category}</span></td><td><span className={`priority ${c.priority?.toLowerCase()}`}>{c.priority}</span></td><td><span className={`status ${c.status?.toLowerCase().replaceAll(" ","-")}`}>{c.status}</span></td><td><span className="sla-text">{fmt(c.sla_due)}</span></td><td><button className="row-arrow" onClick={e=>{e.stopPropagation();onView(c)}}><ArrowUpRight size={16}/></button></td></tr>)}</tbody></table>{!rows.length&&<div className="table-empty">No records match your search.</div>}</div>
}
function Analytics({analytics:a,complaints}){
 const total=Math.max(a.total||0,1);
 return <section className="page-content"><div className="page-heading"><div><p className="eyebrow">PERFORMANCE & INSIGHTS</p><h1>Analytics</h1><p className="subheading">Understand service demand, case progress and SLA performance.</p></div></div><div className="stats-grid"><Stat label="Total complaints" value={a.total||0} icon={FileText} tone="blue" note="All time"/><Stat label="Resolved" value={a.resolved||0} icon={CheckCircle2} tone="green" note={`${Math.round((a.resolved||0)/total*100)}% of total`}/><Stat label="Potential duplicates" value={a.duplicates||0} icon={CopyIcon} tone="amber" note="Flagged for human review"/><Stat label="Overdue" value={a.overdue||0} icon={AlertTriangle} tone="red" note="Open past SLA deadline"/></div><div className="analytics-grid"><div className="panel"><div className="panel-title"><div><h3>Category distribution</h3><p>Number of complaints in each service area</p></div></div>{a.byCategory?.length?a.byCategory.map(c=><div className="bar-row" key={c.name}><div className="bar-label"><span>{c.name}</span><b>{c.value} <small>({Math.round(c.value/total*100)}%)</small></b></div><div className="bar-track large"><i style={{width:`${c.value/total*100}%`}}/></div></div>):<p className="muted">No data available yet.</p>}</div><div className="panel"><div className="panel-title"><div><h3>Status breakdown</h3><p>Current state of all cases</p></div></div>{a.byStatus?.length?a.byStatus.map(s=><div className="status-break" key={s.name}><span className={`status-dot ${s.name.toLowerCase().replaceAll(" ","-")}`}></span><span>{s.name}</span><b>{s.value}</b></div>):<p className="muted">No data available yet.</p>}<div className="insight-note"><Sparkles size={16}/><span>Use this view to compare manual routing with the triage suggestions during evaluation.</span></div></div></div><div className="panel eval-panel"><div><h3>Capstone evaluation checklist</h3><p>Track these measures in your final report using a labelled test set and recorded workflow runs.</p></div><div className="eval-grid"><div><b>Classification F1-score</b><small>Suggested category vs. verified label</small></div><div><b>Routing accuracy</b><small>Correct department assignments</small></div><div><b>SLA compliance</b><small>Resolved within target deadline</small></div><div><b>Duplicate precision</b><small>Correctly flagged similar cases</small></div></div></div></section>
}
function CopyIcon({size=19}){return <FileText size={size}/>}
function Audit({audit}){return <section className="page-content"><div className="page-heading"><div><p className="eyebrow">ACCOUNTABILITY</p><h1>Audit trail</h1><p className="subheading">A chronological record of system and staff actions.</p></div></div><div className="panel audit-panel">{audit.length?audit.map(e=><div className="audit-event" key={e.id}><div className="audit-marker"><Activity size={15}/></div><div className="audit-content"><b>{e.event_type}</b><p>{e.actor} {e.complaint_id?`· Case #${String(e.complaint_id).slice(0,8).toUpperCase()}`:""} </p><small>{fmt(e.created_at)}</small></div></div>):<div className="empty-state"><div className="empty-icon"><ShieldCheck/></div><b>No audit events yet</b><p>Actions will be recorded here as cases move through the workflow.</p></div>}</div></section>}
function Detail({complaint:c,onClose,onUpdate,appeal,setAppeal,onAppeal}){
 const overdue=c.status!=="Resolved"&&c.status!=="Rejected"&&new Date(c.sla_due)<new Date();
 return <div className="overlay detail-overlay" onMouseDown={e=>e.target===e.currentTarget&&onClose()}><aside className="detail-drawer"><div className="drawer-head"><div><p className="eyebrow">CASE DETAILS</p><small className="case-id">#{String(c.id).slice(0,8).toUpperCase()}</small></div><button className="icon-button" onClick={onClose}><X/></button></div><div className="drawer-body"><div className="detail-title"><h2>{c.title}</h2><span className={`status ${c.status?.toLowerCase().replaceAll(" ","-")}`}>{c.status}</span></div><p className="detail-description">{c.description}</p><div className="detail-meta"><div><small>Submitted by</small><b>{c.citizen_name}</b></div><div><small>Language</small><b>{c.language}</b></div><div><small>Created</small><b>{fmt(c.created_at)}</b></div><div><small>Contact</small><b>{c.contact||"Not provided"}</b></div></div><div className="ai-card"><div className="ai-heading"><span><Sparkles size={16}/> Triage assistance</span><span className="assist-label">SUGGESTION</span></div><div className="ai-result"><small>Suggested category</small><b>{c.suggested_category||c.category}</b></div><div className="ai-result"><small>Detected language</small><b>{c.language}</b></div><div className="ai-result"><small>Similar case</small><b>{c.duplicate_of?`Potential duplicate · ${Math.round(Number(c.duplicate_score)*100)}% match`:"No strong match found"}</b></div><p>Automated suggestions can be incorrect. Confirm details before routing or resolving.</p></div><div className="sla-card"><div className="sla-head"><span><Clock3 size={16}/> Service-level target</span><span className={overdue?"overdue-label":""}>{overdue?"Overdue":"Target deadline"}</span></div><b>{fmt(c.sla_due)}</b><small>{c.sla_hours} hour target · {c.priority} priority</small></div><div className="form-section"><h3>Staff actions</h3><label>Status<select value={c.status} onChange={e=>onUpdate(c.id,{status:e.target.value})}>{statuses.map(s=><option key={s}>{s}</option>)}</select></label><label>Verified category<select value={c.category} onChange={e=>onUpdate(c.id,{category:e.target.value})}>{categories.map(s=><option key={s}>{s}</option>)}</select></label><label>Assigned department<select value={c.department} onChange={e=>onUpdate(c.id,{department:e.target.value})}>{departments.map(s=><option key={s}>{s}</option>)}</select></label><label>Priority<select value={c.priority} onChange={e=>onUpdate(c.id,{priority:e.target.value})}><option>Low</option><option>Medium</option><option>High</option></select></label></div><div className="form-section appeal-section"><h3>Citizen appeal</h3>{c.appeal?<div className="existing-appeal"><p>{c.appeal}</p><span className="status under-review">{c.appeal_status||"Pending"}</span></div>:<><p className="muted">Record an appeal for a staff member to review.</p><textarea rows="3" value={appeal} onChange={e=>setAppeal(e.target.value)} placeholder="Write the appeal..."/><button className="secondary full" onClick={onAppeal} disabled={!appeal.trim()}>Submit appeal</button></>}</div></div></aside></div>
}
createRoot(document.getElementById("root")).render(<App/>);
