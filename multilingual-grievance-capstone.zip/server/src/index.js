require("dotenv").config();
const express = require("express");
const cors = require("cors");
const { Pool } = require("pg");
const { v4: uuid } = require("uuid");
const { detectLanguage, suggestCategory, similarity, priorityFor, slaHours } = require("./triage");

const app = express();
const PORT = process.env.PORT || 5000;
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false
});
app.use(cors({ origin: process.env.CLIENT_ORIGIN ? process.env.CLIENT_ORIGIN.split(",").map(x => x.trim()) : true }));
app.use(express.json({ limit: "1mb" }));

async function audit(complaintId, eventType, actor, details = {}) {
  await pool.query("INSERT INTO audit_events (complaint_id,event_type,actor,details) VALUES ($1,$2,$3,$4)", [complaintId, eventType, actor, JSON.stringify(details)]);
}
app.get("/api/health", async (_req, res) => {
  try { await pool.query("SELECT 1"); res.json({ ok: true, service: "grievance-api" }); }
  catch (e) { res.status(503).json({ ok: false, error: "Database unavailable" }); }
});
app.get("/api/complaints", async (_req, res) => {
  try {
    const { rows } = await pool.query("SELECT * FROM complaints ORDER BY created_at DESC LIMIT 200");
    res.json(rows);
  } catch (e) { res.status(500).json({ error: "Could not load complaints" }); }
});
app.post("/api/complaints", async (req, res) => {
  const { citizenName, contact = "", title, description } = req.body || {};
  if (!citizenName?.trim() || !title?.trim() || !description?.trim() || description.trim().length < 8)
    return res.status(400).json({ error: "Name, title and a description of at least 8 characters are required." });
  try {
    const text = `${title} ${description}`;
    const language = detectLanguage(text);
    const suggestion = suggestCategory(text);
    const priority = priorityFor(text, suggestion.category);
    const hours = slaHours(priority);
    const { rows: existing } = await pool.query("SELECT id,title,description FROM complaints WHERE created_at > NOW() - INTERVAL '180 days' ORDER BY created_at DESC LIMIT 200");
    const match = existing.map(c => ({ ...c, score: similarity(text, `${c.title} ${c.description}`) })).sort((a,b) => b.score-a.score)[0];
    const duplicate = match && match.score >= 0.55 ? match : null;
    const { rows } = await pool.query(
      `INSERT INTO complaints (citizen_name,contact,title,description,language,category,suggested_category,department,priority,status,sla_hours,sla_due,duplicate_of,duplicate_score)
       VALUES ($1,$2,$3,$4,$5,$6,$6,$7,$8,'Submitted',$9,NOW()+($9 || ' hours')::interval,$10,$11) RETURNING *`,
      [citizenName.trim(), contact.trim(), title.trim(), description.trim(), language, suggestion.category, suggestion.department, priority, hours, duplicate?.id || null, duplicate?.score || 0]
    );
    await audit(rows[0].id, "Complaint submitted", "Citizen", { language, suggestedCategory: suggestion.category, duplicateCandidate: duplicate?.id || null });
    res.status(201).json({ ...rows[0], duplicateCandidate: duplicate ? { id: duplicate.id, title: duplicate.title, score: Number(duplicate.score.toFixed(2)) } : null });
  } catch (e) { console.error(e); res.status(500).json({ error: "Could not submit complaint" }); }
});
app.patch("/api/complaints/:id", async (req, res) => {
  const { status, category, department, priority } = req.body || {};
  const allowed = ["Submitted","Under Review","In Progress","Resolved","Escalated","Rejected"];
  if (status && !allowed.includes(status)) return res.status(400).json({ error: "Invalid status" });
  try {
    const old = await pool.query("SELECT * FROM complaints WHERE id=$1", [req.params.id]);
    if (!old.rowCount) return res.status(404).json({ error: "Complaint not found" });
    const current = old.rows[0];
    const nextPriority = priority || current.priority;
    const hours = slaHours(nextPriority);
    const { rows } = await pool.query(
      `UPDATE complaints SET status=COALESCE($2,status), category=COALESCE($3,category), department=COALESCE($4,department),
       priority=COALESCE($5,priority), sla_hours=CASE WHEN $5 IS NULL THEN sla_hours ELSE $6 END,
       sla_due=CASE WHEN $5 IS NULL THEN sla_due ELSE NOW()+($6::text || ' hours')::interval END, updated_at=NOW() WHERE id=$1 RETURNING *`,
      [req.params.id, status || null, category || null, department || null, priority || null, hours]
    );
    await audit(req.params.id, "Complaint updated", "Staff", { status: status || current.status, category: category || current.category, department: department || current.department, priority: nextPriority });
    res.json(rows[0]);
  } catch (e) { res.status(500).json({ error: "Could not update complaint" }); }
});
app.post("/api/complaints/:id/appeal", async (req, res) => {
  const { appeal } = req.body || {};
  if (!appeal?.trim()) return res.status(400).json({ error: "Please enter your appeal." });
  try {
    const { rows } = await pool.query("UPDATE complaints SET appeal=$2,appeal_status='Pending',updated_at=NOW() WHERE id=$1 RETURNING *", [req.params.id, appeal.trim()]);
    if (!rows.length) return res.status(404).json({ error: "Complaint not found" });
    await audit(req.params.id, "Appeal submitted", "Citizen", {});
    res.json(rows[0]);
  } catch (e) { res.status(500).json({ error: "Could not submit appeal" }); }
});
app.get("/api/analytics", async (_req,res) => {
  try {
    const { rows } = await pool.query(`SELECT COUNT(*)::int total,
      COUNT(*) FILTER (WHERE status='Resolved')::int resolved,
      COUNT(*) FILTER (WHERE status NOT IN ('Resolved','Rejected') AND sla_due < NOW())::int overdue,
      COUNT(*) FILTER (WHERE duplicate_of IS NOT NULL)::int duplicates,
      COUNT(*) FILTER (WHERE status IN ('Submitted','Under Review'))::int pending FROM complaints`);
    const byCategory = await pool.query("SELECT category name,COUNT(*)::int value FROM complaints GROUP BY category ORDER BY value DESC");
    const byStatus = await pool.query("SELECT status name,COUNT(*)::int value FROM complaints GROUP BY status ORDER BY value DESC");
    res.json({ ...rows[0], byCategory: byCategory.rows, byStatus: byStatus.rows });
  } catch (e) { res.status(500).json({ error: "Could not load analytics" }); }
});
app.get("/api/audit", async (_req,res) => {
  try { const { rows } = await pool.query("SELECT * FROM audit_events ORDER BY created_at DESC LIMIT 50"); res.json(rows); }
  catch (e) { res.status(500).json({ error: "Could not load audit trail" }); }
});
app.use((err,_req,res,_next) => { console.error(err); res.status(500).json({ error: "Unexpected server error" }); });
app.listen(PORT, () => console.log(`Grievance API running on ${PORT}`));
