const categories = [
  { name: "Water Supply", department: "Water Department", terms: ["water", "पाणी", "पानी", "supply", "leak", "गळती", "लीक", "नल", "tap"] },
  { name: "Roads & Potholes", department: "Public Works", terms: ["road", "pothole", "रस्ता", "खड्डा", "सड़क", "गड्ढा", "street"] },
  { name: "Waste Management", department: "Sanitation Department", terms: ["garbage", "waste", "कचरा", "कूड़ा", "सफाई", "cleaning", "dustbin"] },
  { name: "Electricity & Streetlights", department: "Electrical Department", terms: ["electricity", "power", "light", "streetlight", "वीज", "बत्ती", "बिजली", "लाईट"] },
  { name: "Public Safety", department: "Public Safety Cell", terms: ["unsafe", "danger", "safety", "धोका", "सुरक्षा", "खतरा", "harassment"] },
  { name: "Drainage & Sewage", department: "Drainage Department", terms: ["drain", "sewage", "नाला", "गटार", "गटर", "drainage"] },
  { name: "Certificates & Documents", department: "Citizen Services", terms: ["certificate", "document", "birth", "मिळत", "प्रमाणपत्र", "दाखला", "आधार"] }
];

function detectLanguage(text) {
  if (/[ऀ-ॿ]/u.test(text)) {
    if (/[ळ]/u.test(text) || /(आहे|नाही|मला|कृपया|पाणी|रस्ता|कचरा)/u.test(text)) return "Marathi";
    return "Hindi";
  }
  return "English";
}
function tokenize(text) {
  return (text.toLowerCase().match(/[\p{L}\p{N}]+/gu) || [])
    .filter(w => w.length > 2 && !["the","and","for","with","this","that","have","from","मला","आहे","नाही","कृपया"].includes(w));
}
function suggestCategory(text) {
  const lower = text.toLowerCase();
  let best = { category: "Other", department: "General Helpdesk", score: 0 };
  for (const item of categories) {
    const hits = item.terms.filter(term => lower.includes(term.toLowerCase())).length;
    const score = hits / Math.max(1, Math.min(item.terms.length, 3));
    if (hits > 0 && score > best.score) best = { category: item.name, department: item.department, score };
  }
  return best;
}
function similarity(a, b) {
  const A = new Set(tokenize(a)), B = new Set(tokenize(b));
  if (!A.size || !B.size) return 0;
  const intersection = [...A].filter(x => B.has(x)).length;
  return intersection / new Set([...A, ...B]).size;
}
function priorityFor(text, category) {
  const urgent = /(urgent|emergency|danger|accident|fire|धोका|तातडी|आपत्कालीन|खतरा)/iu.test(text);
  if (urgent) return "High";
  if (category === "Public Safety") return "High";
  return "Medium";
}
function slaHours(priority) { return priority === "High" ? 24 : priority === "Low" ? 120 : 72; }

module.exports = { detectLanguage, suggestCategory, similarity, priorityFor, slaHours };
